package edu.handong.csee.java.inheritance;

public class Animal {

	public static void staticClaasMethod() {
		
        System.out.println("동물입니다.(staticClaasMethod)");
    }
	
    public void instansceMethod() {
        System.out.println("동물입니다.(instansceMethod)");
    }
}
