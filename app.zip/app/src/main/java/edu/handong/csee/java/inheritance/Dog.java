package edu.handong.csee.java.inheritance;

public class Dog extends Animal{
	
	public static void staticClaasMethod() {
        System.out.println("강아지입니다.(staticClaasMethod)");
    }
	
	 public void instansceMethod() {
        System.out.println("강아지입니다.(instansceMethod)");
    }

}
