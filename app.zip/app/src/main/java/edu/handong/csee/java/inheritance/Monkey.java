package edu.handong.csee.java.inheritance;

public class Monkey extends Animal{
	public static void staticClaasMethod() {
        System.out.println("원숭이입니다.(staticClaasMethod)");
    }
	
	public void instansceMethod() {
        System.out.println("원숭이입니다.(instansceMethod)");
    }
}
